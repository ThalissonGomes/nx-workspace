import { Injectable } from '@nestjs/common';

// export interface Pessoa {
//   nome: string;
//   idade: number;
// }
@Injectable()
export class AppService {
  // pessoas = [
  //   {
  //     nome: 'Thalisson',
  //     idade: 23,
  //   },
  // ];
  // getData(fruta: string): { message: string } {
  //   return { message: fruta };
  // }
  // listaPessoas() {
  //   return this.pessoas;
  // }
  // addPessoa(p: Pessoa): Pessoa {
  //   this.pessoas.push(p);
  //   return p;
  // }
}
