import { Controller } from '@nestjs/common';

@Controller()
export class AppController {
  // constructor(private readonly appService: AppService) {}
  // @MessagePattern({ role: 'data', cmd: 'get_data' })
  // getData(fruta: string) {
  //   return this.appService.getData(fruta);
  // }
  // @MessagePattern('listar_pessoas')
  // listP() {
  //   return this.appService.listaPessoas();
  // }
  // @MessagePattern('add_pessoas')
  // cadastra(p: Pessoa) {
  //   return this.appService.addPessoa(p);
  // }
}
