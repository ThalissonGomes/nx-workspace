import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import CreateUsuarioDto from './create-usuario.dto';
import { Usuario } from './usuarios.entity';

@Injectable()
export class UsuariosService {
  constructor(
    @InjectRepository(Usuario)
    private userRepo: Repository<Usuario>
  ) {}

  async createUser(usuarioDto: CreateUsuarioDto) {
    try {
      const newUser = this.userRepo.create(usuarioDto);
      const res = await this.userRepo.save(newUser);
      return res;
    } catch (e) {
      Logger.log(e);
      throw e;
    }
  }

  async getAll() {
    return this.userRepo.find();
  }

  async getByUsername(username: string) {
    const user = await this.userRepo.findOneBy({ username });
    if (user) {
      return user;
    }
    throw new HttpException(
      `Usuário com Username: ${username} não encontrado.`,
      HttpStatus.NOT_FOUND
    );
  }

  async getByEmail(email: string) {
    const user = await this.userRepo.findOneBy({ email });
    if (user) {
      return user;
    }
    throw new HttpException(
      `Usuário com Email: ${email} não encontrado.`,
      HttpStatus.NOT_FOUND
    );
  }
}
