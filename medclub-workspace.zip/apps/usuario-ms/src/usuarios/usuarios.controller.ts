import { Controller } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { CreateUserDto } from './create-usuario.dto';
import { UsuariosService } from './usuarios.service';

@Controller()
export class UsuariosController {
  constructor(private readonly uServ: UsuariosService) {}

  @MessagePattern('criar-usuarios')
  addUser(user: CreateUserDto) {
    return this.uServ.createUser(user);
  }

  @MessagePattern('buscar-todos')
  findAllUsers() {
    return this.uServ.getAll();
  }

  @MessagePattern({ role: 'user', cmd: 'get' })
  getUser(data) {
    return this.uServ.getByUsername(data.username);
  }

  @MessagePattern({ role: 'auth', cmd: 'greet' })
  async greet() {
    return 'Greetings authenticated user';
  }
}
