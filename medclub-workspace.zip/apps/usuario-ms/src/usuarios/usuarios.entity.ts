import { hash } from 'bcrypt';
import { IsEmail, IsString, MinLength } from 'class-validator';
import {
  BeforeInsert,
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  Unique,
} from 'typeorm';
import { IUser } from './usuarios.interface';

@Entity()
@Unique(['username'])
@Unique(['email'])
export class Usuario implements IUser {
  @PrimaryGeneratedColumn()
  id: number;

  @IsString()
  @Column()
  username: string;

  @MinLength(8)
  @Column()
  password: string;

  @IsString()
  @Column()
  name: string;

  @IsEmail()
  @Column()
  email: string;

  @CreateDateColumn()
  createdAt: Date;

  @BeforeInsert()
  async hashPassword() {
    this.password = await hash(this.password, 10);
  }
}
