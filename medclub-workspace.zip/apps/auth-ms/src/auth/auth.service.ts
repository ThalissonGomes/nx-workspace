import { JwtService } from '@nestjs/jwt';
import { compareSync } from 'bcrypt';
import {
  catchError,
  throwError,
  timeout,
  TimeoutError,
  firstValueFrom,
} from 'rxjs';
import {
  Inject,
  Injectable,
  RequestTimeoutException,
  Logger,
} from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { IUser } from './usuarios.interface';

@Injectable()
export class AuthService {
  constructor(
    @Inject('USUARIO_MS')
    private readonly cp: ClientProxy,
    private readonly jwtService: JwtService
  ) {}

  create(p: IUser) {
    return this.cp.send('criar-usuarios', p);
  }

  getAll() {
    return this.cp.send('buscar-todos', '');
  }

  async validateUser(username: string, password: string) {
    try {
      const u = await firstValueFrom(
        this.cp.send({ role: 'user', cmd: 'get' }, { username }).pipe(
          timeout(5000),
          catchError((err) => {
            if (err instanceof TimeoutError) {
              return throwError(() => new RequestTimeoutException());
            }
            return throwError(() => err);
          })
        )
      );

      if (compareSync(password, u?.password)) {
        return u;
      }
      return null;
    } catch (e) {
      Logger.log(e);
      throw e;
    }
  }

  async login(user) {
    const payload = { user, sub: user.id };

    return {
      userId: user.id,
      accessToken: this.jwtService.sign(payload),
    };
  }

  greet() {
    return this.cp.send({ role: 'auth', cmd: 'greet' }, '');
  }
  // getData(fruta: string) {
  //   return this.cp.send({ role: 'data', cmd: 'get_data' }, fruta);
  // }

  // listaPessoas() {
  //   return this.cp.send('listar_pessoas', '');
  // }

  // addPessoa(p: { nome: string; idade: number }) {
  //   return this.cp.send('add_pessoas', p);
  // }
}
