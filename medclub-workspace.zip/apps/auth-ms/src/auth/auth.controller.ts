import {
  Body,
  Controller,
  Get,
  Post,
  Request,
  UseGuards,
} from '@nestjs/common';

import { AuthGuard } from '../guards/auth.guards';
import { AuthService } from './auth.service';
import { LocalAuthGuard } from './local-auth.guard';
import { IUser } from './usuarios.interface';

@Controller()
export class AuthController {
  constructor(private readonly aS: AuthService) {}

  @Post('create')
  create(@Body() p: IUser) {
    return this.aS.create(p);
  }

  @Get('listAll')
  getAll() {
    return this.aS.getAll();
  }

  @UseGuards(LocalAuthGuard)
  @Post('auth')
  async login(@Request() req) {
    return this.aS.login(req.user);
  }

  @UseGuards(AuthGuard)
  @Get('greet')
  async greet() {
    return 'Greetings authenticated user';
  }
}
