import {
  Body,
  Controller,
  Delete,
  Get,
  NotFoundException,
  Param,
  ParseUUIDPipe,
  Post,
  UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

import CreateUserDto from '../outros/create-usuario.dto';
import { AuthService } from './auth.service';

@Controller('auth')
@UseGuards(AuthGuard('jwt'))
export class AuthController {
  constructor(private readonly aS: AuthService) {}

  // CREATE
  @Post('create')
  async create(@Body() u: CreateUserDto) {
    return await this.aS.create(u);
  }

  @Get('findAll')
  async findAll() {
    return await this.aS.findAll();
  }

  @Get('findById/:id')
  async findById(@Param('id', new ParseUUIDPipe()) id: string) {
    return this.aS.findOneById(id);
  }

  @Get('findByUsername/:username')
  async findByUsername(@Param('username') username: string) {
    return this.aS.findOneByUsername(username);
  }

  @Delete('delete/:id')
  delete(@Param('id', new ParseUUIDPipe()) id: string) {
    this.aS.delete(id);
  }
}
